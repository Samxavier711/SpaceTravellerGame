
# NEAT-Flappy-Bird
An AI that plays flappy bird! Using the NEAT python module.

# Instructions
Simply run *space_traveller.py* and watch an AI start training itself to play the game of flappy bird!
